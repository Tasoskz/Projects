[Noise Spectral Density - (V/Hz½ or A/Hz½)]
{
   Npanes: 1
   {
      traces: 1 {524290,0,"v(onoise)"}
      X: ('G',0,10000,0,1e+11)
      Y[0]: ('n',0,0,5e-09,5.5e-08)
      Y[1]: ('_',0,1e+308,0,-1e+308)
      Units: "V/Hz½" ('n',0,0,0,0,5e-09,5.5e-08)
      Log: 1 0 0
   }
}
